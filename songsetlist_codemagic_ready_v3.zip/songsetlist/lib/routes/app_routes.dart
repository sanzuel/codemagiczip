import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../presentation/setlist_detail_screen/setlist_detail_screen.dart';
import '../presentation/setlist_library_screen/setlist_library_screen.dart';
import '../presentation/setlists_screen/setlists_screen.dart';
import '../presentation/songs_library_screen/songs_library_screen.dart';
import '../widgets/app_scaffold.dart';

class AppRoutes {
  static const String initial = '/';
  static const String songsLibraryScreen = '/songs-library-screen';
  static const String setlistLibraryScreen = '/setlist-library-screen';
  static const String setlistDetailScreen = '/setlist-detail-screen';
}

final GoRouter appRouter = GoRouter(
  initialLocation: AppRoutes.initial,
  routes: [
    GoRoute(
      path: AppRoutes.initial,
      pageBuilder: (context, state) => CustomTransitionPage(
        key: state.pageKey,
        child: const _MainShell(),
        transitionDuration: const Duration(milliseconds: 280),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
            ),
            child: child,
          );
        },
      ),
    ),
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) =>
          AppScaffold(navigationShell: navigationShell),
      branches: [
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: AppRoutes.songsLibraryScreen,
              builder: (context, state) => const SongsLibraryScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: AppRoutes.setlistLibraryScreen,
              builder: (context, state) => const SetlistLibraryScreen(),
            ),
          ],
        ),
      ],
    ),
    GoRoute(
      path: AppRoutes.setlistDetailScreen,
      builder: (context, state) {
        final extra = state.extra;
        if (extra is SetlistModel) {
          return SetlistDetailScreen(setlistId: extra.id, setlistModel: extra);
        }
        final setlistId = extra as String? ?? '';
        return SetlistDetailScreen(setlistId: setlistId);
      },
    ),
  ],
);

// Redirect splash "/" to the shell's first branch
class _MainShell extends StatelessWidget {
  const _MainShell();

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) {
        context.go(AppRoutes.songsLibraryScreen);
      }
    });
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}
