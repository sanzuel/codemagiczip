import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../presentation/songs_library_screen/songs_library_screen.dart';
import '../presentation/setlists_screen/setlists_screen.dart';

class AppStorage {
  static const _songsKey = 'songsetlist_songs_v2';
  static const _setlistsKey = 'songsetlist_setlists_v2';

  static Future<void> loadAll() async {
    final prefs = await SharedPreferences.getInstance();

    final songsJson = prefs.getString(_songsKey);
    if (songsJson != null && songsJson.isNotEmpty) {
      try {
        final decoded = jsonDecode(songsJson);
        if (decoded is List) {
          final songs = decoded
              .map((e) => SongModel.fromMap(Map<String, dynamic>.from(e)))
              .toList();
          SongsLibraryScreen.sharedSongs
            ..clear()
            ..addAll(songs);
        }
      } catch (_) {
        // Keep bundled defaults if stored data is invalid.
      }
    }

    final setlistsJson = prefs.getString(_setlistsKey);
    if (setlistsJson != null && setlistsJson.isNotEmpty) {
      try {
        final decoded = jsonDecode(setlistsJson);
        if (decoded is List) {
          final setlists = decoded
              .map((e) => SetlistModel.fromMap(Map<String, dynamic>.from(e)))
              .toList();
          SetlistsScreen.sharedSetlists
            ..clear()
            ..addAll(setlists);
        }
      } catch (_) {
        // Keep bundled defaults if stored data is invalid.
      }
    }
  }

  static Future<void> saveSongs() async {
    final prefs = await SharedPreferences.getInstance();
    final data = SongsLibraryScreen.sharedSongs.map((s) => s.toMap()).toList();
    await prefs.setString(_songsKey, jsonEncode(data));
  }

  static Future<void> saveSetlists() async {
    final prefs = await SharedPreferences.getInstance();
    final data = SetlistsScreen.sharedSetlists
        .map((s) => s.toMap())
        .toList();
    await prefs.setString(_setlistsKey, jsonEncode(data));
  }

  static Future<void> saveAll() async {
    await saveSongs();
    await saveSetlists();
  }
}
