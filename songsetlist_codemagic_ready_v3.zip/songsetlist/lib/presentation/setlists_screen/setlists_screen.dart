import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_storage.dart';

import '../../routes/app_routes.dart';
import '../../widgets/empty_state_widget.dart';
import './widgets/add_setlist_sheet_widget.dart';
import './widgets/setlist_card_widget.dart';
import './widgets/setlist_filter_chips_widget.dart';

// TODO: Replace with Riverpod/Bloc for production

enum SetlistStatus { draft, ready, performed }

class SetlistModel {
  final String id;
  final String name;
  final String venue;
  final String date;
  final SetlistStatus status;
  final int songCount;
  final String totalDuration;
  final bool isPinned;
  final List<String> songIds;

  const SetlistModel({
    required this.id,
    required this.name,
    required this.venue,
    required this.date,
    required this.status,
    required this.songCount,
    required this.totalDuration,
    required this.isPinned,
    required this.songIds,
  });

  static SetlistStatus _statusFromString(String v) {
    switch (v) {
      case 'ready':
        return SetlistStatus.ready;
      case 'performed':
        return SetlistStatus.performed;
      default:
        return SetlistStatus.draft;
    }
  }

  factory SetlistModel.fromMap(Map<String, dynamic> map) {
    return SetlistModel(
      id: map['id'] as String,
      name: map['name'] as String,
      venue: map['venue'] as String,
      date: map['date'] as String,
      status: _statusFromString(map['status'] as String),
      songCount: map['songCount'] as int,
      totalDuration: map['totalDuration'] as String,
      isPinned: map['isPinned'] as bool,
      songIds: List<String>.from(map['songIds'] as List),
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'venue': venue,
    'date': date,
    'status': status.name,
    'songCount': songCount,
    'totalDuration': totalDuration,
    'isPinned': isPinned,
    'songIds': songIds,
  };
}

class SetlistsScreen extends StatefulWidget {
  const SetlistsScreen({super.key});

  /// Shared setlist store — mutated in place so all screens see the same list.
  static final List<SetlistModel> sharedSetlists = [
    SetlistModel.fromMap({
      'id': 'sl1',
      'name': 'Friday Night at The Anchor',
      'venue': 'The Anchor Bar',
      'date': 'Aug 22, 2026',
      'status': 'ready',
      'songCount': 12,
      'totalDuration': '47:32',
      'isPinned': true,
      'songIds': [
        's1',
        's3',
        's5',
        's9',
        's2',
        's6',
        's8',
        's4',
        's7',
        's10',
        's1',
        's3',
      ],
    }),
    SetlistModel.fromMap({
      'id': 'sl2',
      'name': 'Acoustic Sunday Session',
      'venue': 'Green Park Café',
      'date': 'Aug 17, 2026',
      'status': 'performed',
      'songCount': 8,
      'totalDuration': '32:14',
      'isPinned': false,
      'songIds': ['s2', 's4', 's7', 's10', 's6', 's9', 's1', 's5'],
    }),
    SetlistModel.fromMap({
      'id': 'sl3',
      'name': 'Late Night Electronic',
      'venue': 'Studio B',
      'date': 'Sep 05, 2026',
      'status': 'draft',
      'songCount': 6,
      'totalDuration': '28:48',
      'isPinned': false,
      'songIds': ['s3', 's8', 's5', 's1', 's9', 's6'],
    }),
    SetlistModel.fromMap({
      'id': 'sl4',
      'name': 'Jazz Brunch Set',
      'venue': 'Rooftop Terrace',
      'date': 'Sep 14, 2026',
      'status': 'draft',
      'songCount': 10,
      'totalDuration': '41:20',
      'isPinned': false,
      'songIds': ['s6', 's2', 's4', 's10', 's7', 's9', 's1', 's3', 's5', 's8'],
    }),
    SetlistModel.fromMap({
      'id': 'sl5',
      'name': 'Summer Closing Party',
      'venue': 'Harbour Stage',
      'date': 'Aug 31, 2026',
      'status': 'ready',
      'songCount': 14,
      'totalDuration': '55:10',
      'isPinned': true,
      'songIds': [
        's1',
        's3',
        's5',
        's8',
        's9',
        's2',
        's6',
        's4',
        's7',
        's10',
        's1',
        's3',
        's5',
        's8',
      ],
    }),
  ];

  @override
  State<SetlistsScreen> createState() => _SetlistsScreenState();
}

class _SetlistsScreenState extends State<SetlistsScreen> {
  // TODO: Replace with Riverpod/Bloc for production
  String _filter = 'All';
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  List<SetlistModel> get _setlists => SetlistsScreen.sharedSetlists;

  final List<Map<String, dynamic>> _setlistMaps = [
    {
      'id': 'sl1',
      'name': 'Friday Night at The Anchor',
      'venue': 'The Anchor Bar',
      'date': 'Aug 22, 2026',
      'status': 'ready',
      'songCount': 12,
      'totalDuration': '47:32',
      'isPinned': true,
      'songIds': [
        's1',
        's3',
        's5',
        's9',
        's2',
        's6',
        's8',
        's4',
        's7',
        's10',
        's1',
        's3',
      ],
    },
    {
      'id': 'sl2',
      'name': 'Acoustic Sunday Session',
      'venue': 'Green Park Café',
      'date': 'Aug 17, 2026',
      'status': 'performed',
      'songCount': 8,
      'totalDuration': '32:14',
      'isPinned': false,
      'songIds': ['s2', 's4', 's7', 's10', 's6', 's9', 's1', 's5'],
    },
    {
      'id': 'sl3',
      'name': 'Late Night Electronic',
      'venue': 'Studio B',
      'date': 'Sep 05, 2026',
      'status': 'draft',
      'songCount': 6,
      'totalDuration': '28:48',
      'isPinned': false,
      'songIds': ['s3', 's8', 's5', 's1', 's9', 's6'],
    },
    {
      'id': 'sl4',
      'name': 'Jazz Brunch Set',
      'venue': 'Rooftop Terrace',
      'date': 'Sep 14, 2026',
      'status': 'draft',
      'songCount': 10,
      'totalDuration': '41:20',
      'isPinned': false,
      'songIds': ['s6', 's2', 's4', 's10', 's7', 's9', 's1', 's3', 's5', 's8'],
    },
    {
      'id': 'sl5',
      'name': 'Summer Closing Party',
      'venue': 'Harbour Stage',
      'date': 'Aug 31, 2026',
      'status': 'ready',
      'songCount': 14,
      'totalDuration': '55:10',
      'isPinned': true,
      'songIds': [
        's1',
        's3',
        's5',
        's8',
        's9',
        's2',
        's6',
        's4',
        's7',
        's10',
        's1',
        's3',
        's5',
        's8',
      ],
    },
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<SetlistModel> get _filtered {
    List<SetlistModel> list = _setlists;
    if (_filter != 'All') {
      list = list.where((s) => s.status.name == _filter.toLowerCase()).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list
          .where(
            (s) =>
                s.name.toLowerCase().contains(q) ||
                s.venue.toLowerCase().contains(q),
          )
          .toList();
    }
    return list;
  }

  void _openAddSetlist() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddSetlistSheetWidget(
        onAdd: (sl) {
          setState(() => SetlistsScreen.sharedSetlists.add(sl));
          AppStorage.saveSetlists();
          Navigator.pop(context);
        },
      ),
    );
  }

  bool get _isTablet => MediaQuery.of(context).size.width >= 600;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final filtered = _filtered;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(theme),
            const SizedBox(height: 12),
            _buildSearchBar(theme),
            const SizedBox(height: 10),
            SetlistFilterChipsWidget(
              selected: _filter,
              onSelected: (f) => setState(() => _filter = f),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Text(
                '${filtered.length} setlist${filtered.length != 1 ? 's' : ''}',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                  ? EmptyStateWidget(
                      icon: Icons.queue_music_outlined,
                      title: 'No setlists yet',
                      subtitle:
                          'Build your first setlist by adding songs in order for your next performance.',
                      actionLabel: 'Create Setlist',
                      onAction: _openAddSetlist,
                    )
                  : _buildGrid(filtered, theme),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SETLISTS',
                  style: GoogleFonts.dmSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 2.0,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Your Performances',
                  style: GoogleFonts.dmSans(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                    letterSpacing: -0.3,
                  ),
                ),
              ],
            ),
          ),
          // Add Setlist button top right
          GestureDetector(
            onTap: _openAddSetlist,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(
                color: theme.colorScheme.primary,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.add_rounded, size: 18, color: Colors.white),
                  const SizedBox(width: 5),
                  Text(
                    'Add Setlist',
                    style: GoogleFonts.dmSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
        ),
        child: TextField(
          controller: _searchController,
          onChanged: (v) => setState(() => _searchQuery = v),
          style: GoogleFonts.dmSans(
            fontSize: 14,
            color: theme.colorScheme.onSurface,
          ),
          decoration: InputDecoration(
            hintText: 'Search setlists…',
            hintStyle: GoogleFonts.dmSans(
              fontSize: 14,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            prefixIcon: Icon(
              Icons.search_rounded,
              size: 20,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            suffixIcon: _searchQuery.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchController.clear();
                      setState(() => _searchQuery = '');
                    },
                    child: Icon(
                      Icons.close_rounded,
                      size: 18,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ),
    );
  }

  Widget _buildGrid(List<SetlistModel> setlists, ThemeData theme) {
    final crossAxisCount = _isTablet ? 3 : 2;
    // +1 for the "Add" card
    final itemCount = setlists.length + 1;

    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 40),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.82,
      ),
      itemCount: itemCount,
      itemBuilder: (context, index) {
        if (index == setlists.length) {
          return _buildAddCard(theme);
        }
        return SetlistCardWidget(
          setlist: setlists[index],
          onTap: () => context.push(
            AppRoutes.setlistDetailScreen,
            extra: setlists[index].id,
          ),
          onPinToggle: () {
            // TODO: Replace with Riverpod/Bloc for production
            setState(() {
              final idx = SetlistsScreen.sharedSetlists.indexWhere(
                (s) => s.id == setlists[index].id,
              );
              if (idx != -1) {
                final s = SetlistsScreen.sharedSetlists[idx];
                SetlistsScreen.sharedSetlists[idx] = SetlistModel(
                  id: s.id,
                  name: s.name,
                  venue: s.venue,
                  date: s.date,
                  status: s.status,
                  songCount: s.songCount,
                  totalDuration: s.totalDuration,
                  isPinned: !s.isPinned,
                  songIds: s.songIds,
                );
              }
            });
            AppStorage.saveSetlists();
          },
        );
      },
    );
  }

  Widget _buildAddCard(ThemeData theme) {
    return GestureDetector(
      onTap: _openAddSetlist,
      child: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.colorScheme.outline, width: 1.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.add_rounded,
                size: 22,
                color: theme.colorScheme.primary,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'NEW SETLIST',
              style: GoogleFonts.dmSans(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.5,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
