import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../setlists_screen.dart';

class SetlistCardWidget extends StatelessWidget {
  final SetlistModel setlist;
  final VoidCallback onTap;
  final VoidCallback onPinToggle;

  const SetlistCardWidget({
    required this.setlist,
    required this.onTap,
    required this.onPinToggle,
    super.key,
  });

  Color _statusColor(SetlistStatus s, ThemeData theme) {
    switch (s) {
      case SetlistStatus.ready:
        return const Color(0xFF2D7A4F);
      case SetlistStatus.performed:
        return theme.colorScheme.primary;
      case SetlistStatus.draft:
        return theme.colorScheme.onSurfaceVariant;
    }
  }

  IconData _statusIcon(SetlistStatus s) {
    switch (s) {
      case SetlistStatus.ready:
        return Icons.check_circle_outline_rounded;
      case SetlistStatus.performed:
        return Icons.star_outline_rounded;
      case SetlistStatus.draft:
        return Icons.edit_outlined;
    }
  }

  String _statusLabel(SetlistStatus s) {
    switch (s) {
      case SetlistStatus.ready:
        return 'READY';
      case SetlistStatus.performed:
        return 'DONE';
      case SetlistStatus.draft:
        return 'DRAFT';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final sc = _statusColor(setlist.status, theme);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        splashColor: theme.colorScheme.primary.withAlpha(15),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: theme.colorScheme.outlineVariant,
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top row: status icon + pin icon
              Row(
                children: [
                  Icon(_statusIcon(setlist.status), size: 18, color: sc),
                  const Spacer(),
                  GestureDetector(
                    onTap: onPinToggle,
                    child: Icon(
                      setlist.isPinned
                          ? Icons.bookmark
                          : Icons.bookmark_outline,
                      size: 18,
                      color: setlist.isPinned
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              // Setlist name
              Expanded(
                child: Text(
                  setlist.name,
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                    height: 1.3,
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              // Dashed divider
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: _DashedDivider(color: theme.colorScheme.outlineVariant),
              ),
              // Venue
              Text(
                setlist.venue,
                style: GoogleFonts.dmSans(
                  fontSize: 11,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              // Date + song count row
              Row(
                children: [
                  Text(
                    setlist.date,
                    style: GoogleFonts.dmSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                      fontFeatures: [const FontFeature.tabularFigures()],
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${setlist.songCount} songs',
                    style: GoogleFonts.dmSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: sc,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DashedDivider extends StatelessWidget {
  final Color color;
  const _DashedDivider({required this.color});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final dashWidth = 6.0;
        final dashGap = 4.0;
        final count = (constraints.maxWidth / (dashWidth + dashGap)).floor();
        return Row(
          children: List.generate(
            count,
            (i) => Container(
              width: dashWidth,
              height: 1,
              margin: EdgeInsets.only(right: i < count - 1 ? dashGap : 0),
              color: color,
            ),
          ),
        );
      },
    );
  }
}
