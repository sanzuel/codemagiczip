import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../setlists_screen.dart';

class AddSetlistSheetWidget extends StatefulWidget {
  final ValueChanged<SetlistModel> onAdd;

  const AddSetlistSheetWidget({required this.onAdd, super.key});

  @override
  State<AddSetlistSheetWidget> createState() => _AddSetlistSheetWidgetState();
}

class _AddSetlistSheetWidgetState extends State<AddSetlistSheetWidget> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _venueCtrl = TextEditingController();
  final _dateCtrl = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _venueCtrl.dispose();
    _dateCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    // TODO: Replace with Riverpod/Bloc for production
    final sl = SetlistModel(
      id: 'sl${DateTime.now().millisecondsSinceEpoch}',
      name: _nameCtrl.text.trim(),
      venue: _venueCtrl.text.trim().isEmpty ? 'TBD' : _venueCtrl.text.trim(),
      date: _dateCtrl.text.trim().isEmpty ? 'TBD' : _dateCtrl.text.trim(),
      status: SetlistStatus.draft,
      songCount: 0,
      totalDuration: '0:00',
      isPinned: false,
      songIds: [],
    );
    widget.onAdd(sl);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(
        24,
        20,
        24,
        MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: theme.colorScheme.outline,
                  borderRadius: BorderRadius.circular(100),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'New Setlist',
              style: GoogleFonts.dmSans(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 20),
            _field(
              ctrl: _nameCtrl,
              label: 'Setlist Name',
              hint: 'e.g. Friday Night at The Anchor',
              theme: theme,
              validator: (v) =>
                  v == null || v.isEmpty ? 'Name is required' : null,
            ),
            const SizedBox(height: 16),
            _field(
              ctrl: _venueCtrl,
              label: 'Venue (optional)',
              hint: 'e.g. The Anchor Bar',
              theme: theme,
            ),
            const SizedBox(height: 16),
            _field(
              ctrl: _dateCtrl,
              label: 'Date (optional)',
              hint: 'e.g. Aug 22, 2026',
              theme: theme,
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: FilledButton(
                onPressed: _isLoading ? null : _submit,
                style: FilledButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : Text(
                        'Create Setlist',
                        style: GoogleFonts.dmSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field({
    required TextEditingController ctrl,
    required String label,
    required String hint,
    required ThemeData theme,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 4),
        TextFormField(
          controller: ctrl,
          validator: validator,
          style: GoogleFonts.dmSans(
            fontSize: 14,
            color: theme.colorScheme.onSurface,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: GoogleFonts.dmSans(
              fontSize: 14,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            border: UnderlineInputBorder(
              borderSide: BorderSide(color: theme.colorScheme.outline),
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: theme.colorScheme.outline),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: theme.colorScheme.primary,
                width: 2,
              ),
            ),
            errorBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: theme.colorScheme.error),
            ),
            isDense: true,
            contentPadding: const EdgeInsets.symmetric(vertical: 8),
          ),
        ),
      ],
    );
  }
}
