import 'package:flutter/material.dart';

import '../../core/app_storage.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../routes/app_routes.dart';
import '../../widgets/empty_state_widget.dart';
import '../setlists_screen/setlists_screen.dart';
import '../setlists_screen/widgets/add_setlist_sheet_widget.dart';
import './widgets/library_setlist_tile_widget.dart';

class SetlistLibraryScreen extends StatefulWidget {
  const SetlistLibraryScreen({super.key});

  @override
  State<SetlistLibraryScreen> createState() => _SetlistLibraryScreenState();
}

class _SetlistLibraryScreenState extends State<SetlistLibraryScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedFilter = 'All';
  String _sortBy = 'Date';
  bool _isGridView = false;

  List<SetlistModel> get _setlists => SetlistsScreen.sharedSetlists;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() => _searchQuery = _searchController.text.toLowerCase());
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<SetlistModel> get _filtered {
    List<SetlistModel> result = List.from(_setlists);

    // Filter by status
    if (_selectedFilter != 'All') {
      result = result
          .where((s) => s.status.name == _selectedFilter.toLowerCase())
          .toList();
    }

    // Filter by search
    if (_searchQuery.isNotEmpty) {
      result = result
          .where(
            (s) =>
                s.name.toLowerCase().contains(_searchQuery) ||
                s.venue.toLowerCase().contains(_searchQuery),
          )
          .toList();
    }

    // Sort
    switch (_sortBy) {
      case 'Name':
        result.sort((a, b) => a.name.compareTo(b.name));
        break;
      case 'Songs':
        result.sort((a, b) => b.songCount.compareTo(a.songCount));
        break;
      case 'Date':
      default:
        // Pinned first, then by original order
        result.sort((a, b) {
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
          return 0;
        });
    }

    return result;
  }

  int get _totalSongs => _setlists.fold(0, (sum, s) => sum + s.songCount);

  int get _readyCount =>
      _setlists.where((s) => s.status == SetlistStatus.ready).length;

  int get _draftCount =>
      _setlists.where((s) => s.status == SetlistStatus.draft).length;

  int get _performedCount =>
      _setlists.where((s) => s.status == SetlistStatus.performed).length;

  void _openAddSetlist() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddSetlistSheetWidget(
        onAdd: (sl) {
          setState(() => SetlistsScreen.sharedSetlists.add(sl));
          AppStorage.saveSetlists();
          Navigator.pop(context);
        },
      ),
    );
  }

  void _deleteSetlist(String id) {
    setState(
      () => SetlistsScreen.sharedSetlists.removeWhere((s) => s.id == id),
    );
    AppStorage.saveSetlists();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Setlist removed from library',
          style: GoogleFonts.dmSans(fontSize: 13),
        ),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1A1714),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _togglePin(String id) {
    setState(() {
      final idx = SetlistsScreen.sharedSetlists.indexWhere((s) => s.id == id);
      if (idx != -1) {
        final s = SetlistsScreen.sharedSetlists[idx];
        SetlistsScreen.sharedSetlists[idx] = SetlistModel(
          id: s.id,
          name: s.name,
          venue: s.venue,
          date: s.date,
          status: s.status,
          songCount: s.songCount,
          totalDuration: s.totalDuration,
          isPinned: !s.isPinned,
          songIds: s.songIds,
        );
      }
    });
    AppStorage.saveSetlists();
  }

  void _showEditSheet(SetlistModel setlist) {
    final theme = Theme.of(context);
    final nameController = TextEditingController(text: setlist.name);
    final venueController = TextEditingController(text: setlist.venue);
    SetlistStatus selectedStatus = setlist.status;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(ctx).viewInsets.bottom,
              ),
              child: Container(
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(20),
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 36,
                        height: 4,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.outlineVariant,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Edit Setlist',
                      style: GoogleFonts.dmSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Name',
                      style: GoogleFonts.dmSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      controller: nameController,
                      style: GoogleFonts.dmSans(
                        fontSize: 14,
                        color: theme.colorScheme.onSurface,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Setlist name',
                        hintStyle: GoogleFonts.dmSans(
                          fontSize: 13,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        filled: true,
                        fillColor: theme.colorScheme.surfaceContainerHighest,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 12,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Venue',
                      style: GoogleFonts.dmSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      controller: venueController,
                      style: GoogleFonts.dmSans(
                        fontSize: 14,
                        color: theme.colorScheme.onSurface,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Venue name',
                        hintStyle: GoogleFonts.dmSans(
                          fontSize: 13,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        filled: true,
                        fillColor: theme.colorScheme.surfaceContainerHighest,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 12,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Status',
                      style: GoogleFonts.dmSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: SetlistStatus.values.map((s) {
                        final isSelected = selectedStatus == s;
                        final label =
                            s.name[0].toUpperCase() + s.name.substring(1);
                        return Expanded(
                          child: GestureDetector(
                            onTap: () =>
                                setSheetState(() => selectedStatus = s),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              margin: const EdgeInsets.only(right: 6),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? theme.colorScheme.primary
                                    : theme.colorScheme.surfaceContainerHighest,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                label,
                                style: GoogleFonts.dmSans(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: isSelected
                                      ? Colors.white
                                      : theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          final newName = nameController.text.trim();
                          final newVenue = venueController.text.trim();
                          if (newName.isEmpty) return;
                          setState(() {
                            final idx = SetlistsScreen.sharedSetlists
                                .indexWhere((s) => s.id == setlist.id);
                            if (idx != -1) {
                              final s = SetlistsScreen.sharedSetlists[idx];
                              SetlistsScreen.sharedSetlists[idx] = SetlistModel(
                                id: s.id,
                                name: newName,
                                venue: newVenue.isEmpty ? s.venue : newVenue,
                                date: s.date,
                                status: selectedStatus,
                                songCount: s.songCount,
                                totalDuration: s.totalDuration,
                                isPinned: s.isPinned,
                                songIds: s.songIds,
                              );
                            }
                          });
                          AppStorage.saveSetlists();
                          Navigator.pop(ctx);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Setlist updated',
                                style: GoogleFonts.dmSans(fontSize: 13),
                              ),
                              behavior: SnackBarBehavior.floating,
                              backgroundColor: const Color(0xFF1A1714),
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: theme.colorScheme.primary,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'Save Changes',
                          style: GoogleFonts.dmSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showSortSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final theme = Theme.of(ctx);
        return Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.outlineVariant,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Sort by',
                style: GoogleFonts.dmSans(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 12),
              ...['Date', 'Name', 'Songs'].map((option) {
                final isSelected = _sortBy == option;
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    option,
                    style: GoogleFonts.dmSans(
                      fontSize: 14,
                      fontWeight: isSelected
                          ? FontWeight.w600
                          : FontWeight.w400,
                      color: isSelected
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurface,
                    ),
                  ),
                  trailing: isSelected
                      ? Icon(
                          Icons.check_rounded,
                          color: theme.colorScheme.primary,
                          size: 18,
                        )
                      : null,
                  onTap: () {
                    setState(() => _sortBy = option);
                    Navigator.pop(ctx);
                  },
                );
              }),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final filtered = _filtered;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(theme),
            const SizedBox(height: 12),
            _buildSearchBar(theme),
            const SizedBox(height: 10),
            _buildFilterRow(theme),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Text(
                '${filtered.length} setlist${filtered.length != 1 ? 's' : ''}',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                  ? EmptyStateWidget(
                      icon: Icons.library_music_outlined,
                      title: _searchQuery.isNotEmpty
                          ? 'No results found'
                          : 'Your library is empty',
                      subtitle: _searchQuery.isNotEmpty
                          ? 'Try a different search term or filter.'
                          : 'Create your first setlist to start building your library.',
                      actionLabel: _searchQuery.isEmpty
                          ? 'Create Setlist'
                          : null,
                      onAction: _searchQuery.isEmpty ? _openAddSetlist : null,
                    )
                  : _isGridView
                  ? _buildGrid(filtered, theme)
                  : _buildList(filtered, theme),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddSetlist,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Setlist'),
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Row(
        children: [
          const Spacer(),
          // View toggle
          Container(
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                _ViewToggleButton(
                  icon: Icons.view_list_rounded,
                  isActive: !_isGridView,
                  onTap: () => setState(() => _isGridView = false),
                ),
                _ViewToggleButton(
                  icon: Icons.grid_view_rounded,
                  isActive: _isGridView,
                  onTap: () => setState(() => _isGridView = true),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          // Sort button
          GestureDetector(
            onTap: _showSortSheet,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.sort_rounded,
                size: 20,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: TextField(
          controller: _searchController,
          style: GoogleFonts.dmSans(
            fontSize: 14,
            color: theme.colorScheme.onSurface,
          ),
          decoration: InputDecoration(
            hintText: 'Search setlists, venues…',
            hintStyle: GoogleFonts.dmSans(
              fontSize: 13,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            prefixIcon: Icon(
              Icons.search_rounded,
              size: 18,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            suffixIcon: _searchQuery.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchController.clear();
                      setState(() => _searchQuery = '');
                    },
                    child: Icon(
                      Icons.close_rounded,
                      size: 16,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  )
                : null,
            border: InputBorder.none,
            enabledBorder: InputBorder.none,
            focusedBorder: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterRow(ThemeData theme) {
    final filters = ['All', 'Ready', 'Draft', 'Performed'];
    return SizedBox(
      height: 34,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final f = filters[i];
          final isSelected = _selectedFilter == f;
          return GestureDetector(
            onTap: () => setState(() => _selectedFilter = f),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: isSelected
                    ? theme.colorScheme.primary
                    : theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isSelected
                      ? theme.colorScheme.primary
                      : theme.colorScheme.outlineVariant,
                ),
              ),
              child: Text(
                f,
                style: GoogleFonts.dmSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isSelected
                      ? Colors.white
                      : theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildList(List<SetlistModel> setlists, ThemeData theme) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
      itemCount: setlists.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final setlist = setlists[index];
        return LibrarySetlistTileWidget(
          setlist: setlist,
          onTap: () => context
              .push(AppRoutes.setlistDetailScreen, extra: setlist)
              .then((_) => setState(() {})),
          onPinToggle: () => _togglePin(setlist.id),
          onDelete: () => _deleteSetlist(setlist.id),
          onEdit: () => _showEditSheet(setlist),
        );
      },
    );
  }

  Widget _buildGrid(List<SetlistModel> setlists, ThemeData theme) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.85,
      ),
      itemCount: setlists.length,
      itemBuilder: (context, index) {
        final setlist = setlists[index];
        return LibrarySetlistTileWidget(
          setlist: setlist,
          isGridMode: true,
          onTap: () => context
              .push(AppRoutes.setlistDetailScreen, extra: setlist)
              .then((_) => setState(() {})),
          onPinToggle: () => _togglePin(setlist.id),
          onDelete: () => _deleteSetlist(setlist.id),
          onEdit: () => _showEditSheet(setlist),
        );
      },
    );
  }
}

class _ViewToggleButton extends StatelessWidget {
  final IconData icon;
  final bool isActive;
  final VoidCallback onTap;

  const _ViewToggleButton({
    required this.icon,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: isActive ? theme.colorScheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(
          icon,
          size: 18,
          color: isActive ? Colors.white : theme.colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
