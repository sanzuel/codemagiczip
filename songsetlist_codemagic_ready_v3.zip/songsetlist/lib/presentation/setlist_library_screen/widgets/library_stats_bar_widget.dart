import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LibraryStatsBarWidget extends StatelessWidget {
  final int total;
  final int ready;
  final int draft;
  final int performed;
  final int totalSongs;

  const LibraryStatsBarWidget({
    required this.total,
    required this.ready,
    required this.draft,
    required this.performed,
    required this.totalSongs,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Row(
        children: [
          _StatItem(
            value: '$total',
            label: 'Total',
            color: theme.colorScheme.onSurface,
          ),
          _Divider(),
          _StatItem(
            value: '$ready',
            label: 'Ready',
            color: const Color(0xFF2D7A4F),
          ),
          _Divider(),
          _StatItem(
            value: '$draft',
            label: 'Draft',
            color: theme.colorScheme.onSurfaceVariant,
          ),
          _Divider(),
          _StatItem(
            value: '$performed',
            label: 'Done',
            color: theme.colorScheme.primary,
          ),
          _Divider(),
          _StatItem(
            value: '$totalSongs',
            label: 'Songs',
            color: theme.colorScheme.secondary,
          ),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String value;
  final String label;
  final Color color;

  const _StatItem({
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: GoogleFonts.dmSans(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: GoogleFonts.dmSans(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: theme.colorScheme.onSurfaceVariant,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: 1,
      height: 28,
      color: theme.colorScheme.outlineVariant,
      margin: const EdgeInsets.symmetric(horizontal: 4),
    );
  }
}
