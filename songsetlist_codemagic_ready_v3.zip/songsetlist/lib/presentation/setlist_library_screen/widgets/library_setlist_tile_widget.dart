import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../setlists_screen/setlists_screen.dart';

class LibrarySetlistTileWidget extends StatelessWidget {
  final SetlistModel setlist;
  final VoidCallback onTap;
  final VoidCallback onPinToggle;
  final VoidCallback onDelete;
  final VoidCallback? onEdit;
  final bool isGridMode;

  const LibrarySetlistTileWidget({
    required this.setlist,
    required this.onTap,
    required this.onPinToggle,
    required this.onDelete,
    this.onEdit,
    this.isGridMode = false,
    super.key,
  });

  Color _statusColor(SetlistStatus s, ThemeData theme) {
    switch (s) {
      case SetlistStatus.ready:
        return const Color(0xFF2D7A4F);
      case SetlistStatus.performed:
        return theme.colorScheme.primary;
      case SetlistStatus.draft:
        return theme.colorScheme.onSurfaceVariant;
    }
  }

  String _statusLabel(SetlistStatus s) {
    switch (s) {
      case SetlistStatus.ready:
        return 'READY';
      case SetlistStatus.performed:
        return 'DONE';
      case SetlistStatus.draft:
        return 'DRAFT';
    }
  }

  IconData _statusIcon(SetlistStatus s) {
    switch (s) {
      case SetlistStatus.ready:
        return Icons.check_circle_outline_rounded;
      case SetlistStatus.performed:
        return Icons.star_outline_rounded;
      case SetlistStatus.draft:
        return Icons.edit_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isGridMode) return _buildGridCard(context);
    return _buildListTile(context);
  }

  Widget _buildListTile(BuildContext context) {
    final theme = Theme.of(context);
    final sc = _statusColor(setlist.status, theme);

    return Dismissible(
      key: ValueKey(setlist.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: theme.colorScheme.error,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.delete_outline_rounded,
              color: Colors.white,
              size: 22,
            ),
            const SizedBox(height: 2),
            Text(
              'Delete',
              style: GoogleFonts.dmSans(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
      confirmDismiss: (_) async {
        return await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text(
                  'Delete Setlist',
                  style: GoogleFonts.dmSans(fontWeight: FontWeight.w700),
                ),
                content: Text(
                  'Remove "${setlist.name}" from your library?',
                  style: GoogleFonts.dmSans(fontSize: 14),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: Text('Cancel', style: GoogleFonts.dmSans()),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    child: Text(
                      'Delete',
                      style: GoogleFonts.dmSans(color: theme.colorScheme.error),
                    ),
                  ),
                ],
              ),
            ) ??
            false;
      },
      onDismissed: (_) => onDelete(),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          onLongPress: onEdit,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: theme.colorScheme.outlineVariant),
            ),
            child: Row(
              children: [
                // Content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          if (setlist.isPinned) ...[
                            Icon(
                              Icons.bookmark,
                              size: 12,
                              color: theme.colorScheme.primary,
                            ),
                            const SizedBox(width: 4),
                          ],
                          Expanded(
                            child: Text(
                              setlist.name,
                              style: GoogleFonts.dmSans(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: theme.colorScheme.onSurface,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        setlist.venue,
                        style: GoogleFonts.dmSans(
                          fontSize: 12,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                // Right side: date, songs, status badge
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: sc.withAlpha(20),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        _statusLabel(setlist.status),
                        style: GoogleFonts.dmSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: sc,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${setlist.songCount} songs',
                      style: GoogleFonts.dmSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      setlist.date,
                      style: GoogleFonts.dmSans(
                        fontSize: 11,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGridCard(BuildContext context) {
    final theme = Theme.of(context);
    final sc = _statusColor(setlist.status, theme);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        onLongPress: onEdit,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.colorScheme.outlineVariant),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(_statusIcon(setlist.status), size: 18, color: sc),
                  const Spacer(),
                  GestureDetector(
                    onTap: onPinToggle,
                    child: Icon(
                      setlist.isPinned
                          ? Icons.bookmark
                          : Icons.bookmark_outline,
                      size: 18,
                      color: setlist.isPinned
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Expanded(
                child: Text(
                  setlist.name,
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                    height: 1.3,
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                setlist.venue,
                style: GoogleFonts.dmSans(
                  fontSize: 11,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: sc.withAlpha(20),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      _statusLabel(setlist.status),
                      style: GoogleFonts.dmSans(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: sc,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${setlist.songCount}',
                    style: GoogleFonts.dmSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: sc,
                    ),
                  ),
                  Text(
                    ' songs',
                    style: GoogleFonts.dmSans(
                      fontSize: 11,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
