import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../songs_library_screen.dart';

class AddSongSheetWidget extends StatefulWidget {
  final ValueChanged<SongModel> onAdd;
  final SongModel? existingSong;

  const AddSongSheetWidget({required this.onAdd, this.existingSong, super.key});

  @override
  State<AddSongSheetWidget> createState() => _AddSongSheetWidgetState();
}

class _AddSongSheetWidgetState extends State<AddSongSheetWidget> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _artistCtrl = TextEditingController();
  final _bpmCtrl = TextEditingController();
  final _durationCtrl = TextEditingController();
  String _selectedGenre = 'Indie Rock';
  bool _isLoading = false;

  bool get _isEditing => widget.existingSong != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      final s = widget.existingSong!;
      _titleCtrl.text = s.title;
      _artistCtrl.text = s.artist;
      _bpmCtrl.text = s.bpm.toString();
      _durationCtrl.text = s.duration;
      _selectedGenre = s.genre;
    }
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _artistCtrl.dispose();
    _bpmCtrl.dispose();
    _durationCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    // TODO: Replace with Riverpod/Bloc for production
    final song = SongModel(
      id: _isEditing
          ? widget.existingSong!.id
          : 's${DateTime.now().millisecondsSinceEpoch}',
      title: _titleCtrl.text.trim(),
      artist: _artistCtrl.text.trim(),
      bpm: int.parse(_bpmCtrl.text.trim()),
      genre: _selectedGenre,
      duration: _durationCtrl.text.trim().isEmpty
          ? '0:00'
          : _durationCtrl.text.trim(),
      isFavorite: _isEditing ? widget.existingSong!.isFavorite : false,
      semanticLabel:
          'Music note icon representing ${_titleCtrl.text.trim()} song',
    );
    widget.onAdd(song);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(
        24,
        20,
        24,
        MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Handle
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.outline,
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                _isEditing ? 'Edit Song' : 'Add Song',
                style: GoogleFonts.dmSans(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 20),
              // Title
              _buildField(
                controller: _titleCtrl,
                label: 'Song Title',
                hint: 'e.g. Midnight Drive',
                theme: theme,
                validator: (v) =>
                    v == null || v.isEmpty ? 'Title is required' : null,
              ),
              const SizedBox(height: 16),
              // Artist
              _buildField(
                controller: _artistCtrl,
                label: 'Artist',
                hint: 'e.g. Lena Voss',
                theme: theme,
                validator: (v) =>
                    v == null || v.isEmpty ? 'Artist is required' : null,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _buildField(
                      controller: _bpmCtrl,
                      label: 'BPM',
                      hint: '120',
                      theme: theme,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Required';
                        final n = int.tryParse(v);
                        if (n == null || n < 20 || n > 300) return '20–300';
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _buildField(
                      controller: _durationCtrl,
                      label: 'Duration',
                      hint: '3:45',
                      theme: theme,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Genre dropdown
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Genre',
                    style: GoogleFonts.dmSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(color: theme.colorScheme.outline),
                      ),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _selectedGenre,
                        isExpanded: true,
                        style: GoogleFonts.dmSans(
                          fontSize: 14,
                          color: theme.colorScheme.onSurface,
                        ),
                        items: _genres
                            .map(
                              (g) => DropdownMenuItem(value: g, child: Text(g)),
                            )
                            .toList(),
                        onChanged: (v) => setState(() => _selectedGenre = v!),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  onPressed: _isLoading ? null : _submit,
                  style: FilledButton.styleFrom(
                    backgroundColor: theme.colorScheme.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          _isEditing ? 'Save Changes' : 'Add to Library',
                          style: GoogleFonts.dmSans(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required ThemeData theme,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 4),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          inputFormatters: inputFormatters,
          validator: validator,
          style: GoogleFonts.dmSans(
            fontSize: 14,
            color: theme.colorScheme.onSurface,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: GoogleFonts.dmSans(
              fontSize: 14,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            border: UnderlineInputBorder(
              borderSide: BorderSide(color: theme.colorScheme.outline),
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: theme.colorScheme.outline),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: theme.colorScheme.primary,
                width: 2,
              ),
            ),
            errorBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: theme.colorScheme.error),
            ),
            isDense: true,
            contentPadding: const EdgeInsets.symmetric(vertical: 8),
          ),
        ),
      ],
    );
  }

  static const List<String> _genres = [
    'Indie Rock',
    'Folk',
    'Electronic',
    'Soul',
    'Post-Punk',
    'Jazz-Funk',
    'Acoustic',
    'Synth-Pop',
    'Indie Pop',
    'R&B',
    'Pop',
    'Hip-Hop',
    'Country',
    'Blues',
    'Classical',
  ];
}
