import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BpmFilterChipsWidget extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onSelected;

  const BpmFilterChipsWidget({
    required this.selected,
    required this.onSelected,
    super.key,
  });

  static const List<Map<String, String>> _filters = [
    {'label': 'All', 'sub': ''},
    {'label': 'Slow', 'sub': '≤80 BPM'},
    {'label': 'Mid', 'sub': '80–120'},
    {'label': 'Fast', 'sub': '120+'},
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      height: 36,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: _filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final f = _filters[i];
          final isActive = selected == f['label'];
          return GestureDetector(
            onTap: () => onSelected(f['label']!),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOutCubic,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: isActive
                    ? theme.colorScheme.primary
                    : theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(100),
                border: Border.all(
                  color: isActive
                      ? theme.colorScheme.primary
                      : theme.colorScheme.outline,
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    f['label']!,
                    style: GoogleFonts.dmSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: isActive
                          ? Colors.white
                          : theme.colorScheme.onSurface,
                    ),
                  ),
                  if (f['sub']!.isNotEmpty) ...[
                    const SizedBox(width: 4),
                    Text(
                      f['sub']!,
                      style: GoogleFonts.dmSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w400,
                        color: isActive
                            ? Colors.white70
                            : theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
