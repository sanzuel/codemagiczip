import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../songs_library_screen.dart';

class SongListItemWidget extends StatefulWidget {
  final SongModel song;
  final VoidCallback onFavoriteToggle;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const SongListItemWidget({
    required this.song,
    required this.onFavoriteToggle,
    this.onEdit,
    this.onDelete,
    super.key,
  });

  @override
  State<SongListItemWidget> createState() => _SongListItemWidgetState();
}

class _SongListItemWidgetState extends State<SongListItemWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _swipeController;
  late Animation<Offset> _slideAnimation;
  bool _isRevealed = false;

  @override
  void initState() {
    super.initState();
    _swipeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _slideAnimation =
        Tween<Offset>(begin: Offset.zero, end: const Offset(0.38, 0)).animate(
          CurvedAnimation(parent: _swipeController, curve: Curves.easeOutCubic),
        );
  }

  @override
  void dispose() {
    _swipeController.dispose();
    super.dispose();
  }

  void _toggle() {
    if (_isRevealed) {
      _swipeController.reverse();
    } else {
      _swipeController.forward();
    }
    setState(() => _isRevealed = !_isRevealed);
  }

  void _close() {
    if (_isRevealed) {
      _swipeController.reverse();
      setState(() => _isRevealed = false);
    }
  }

  Color _tempoColor(int bpm) {
    return const Color(0xFF3EB489);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final tc = _tempoColor(widget.song.bpm);

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        if (details.primaryVelocity != null) {
          if (details.primaryVelocity! > 100 && !_isRevealed) {
            _toggle();
          } else if (details.primaryVelocity! < -100 && _isRevealed) {
            _toggle();
          }
        }
      },
      onTap: _isRevealed ? _close : null,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            // Background action buttons (revealed on swipe)
            Positioned.fill(
              child: Row(
                children: [
                  // Edit button
                  _ActionButton(
                    color: const Color(0xFF1E6FD9),
                    icon: Icons.edit_rounded,
                    label: 'Edit',
                    onTap: () {
                      _close();
                      widget.onEdit?.call();
                    },
                  ),
                  // Delete button
                  _ActionButton(
                    color: const Color(0xFFD93025),
                    icon: Icons.delete_rounded,
                    label: 'Delete',
                    onTap: () {
                      _close();
                      widget.onDelete?.call();
                    },
                  ),
                  // Remaining space (same color as card)
                  Expanded(child: Container(color: theme.colorScheme.surface)),
                ],
              ),
            ),
            // Foreground card (slides right)
            SlideTransition(
              position: _slideAnimation,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: _isRevealed ? _close : () {},
                  borderRadius: BorderRadius.circular(16),
                  splashColor: theme.colorScheme.primary.withAlpha(15),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: theme.colorScheme.outlineVariant,
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        // Title + subtitle
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.song.title,
                                style: GoogleFonts.dmSans(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: theme.colorScheme.onSurface,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '${widget.song.artist} · ${widget.song.genre}',
                                style: GoogleFonts.dmSans(
                                  fontSize: 12,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        // Badges column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: tc.withAlpha(26),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                '${widget.song.bpm} BPM',
                                style: GoogleFonts.dmSans(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: tc,
                                  fontFeatures: [
                                    const FontFeature.tabularFigures(),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        // end of row
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ActionButton({
    required this.color,
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 72,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(height: 4),
            Text(
              label,
              style: GoogleFonts.dmSans(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
