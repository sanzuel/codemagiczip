import 'package:flutter/material.dart';

import '../../core/app_storage.dart';

import '../../widgets/empty_state_widget.dart';
import './widgets/add_song_sheet_widget.dart';
import './widgets/song_list_item_widget.dart';
import './widgets/songs_search_bar_widget.dart';

// TODO: Replace with Riverpod/Bloc for production

class SongModel {
  final String id;
  final String title;
  final String artist;
  final int bpm;
  final String genre;
  final String duration; // mm:ss
  final bool isFavorite;
  final String semanticLabel;

  const SongModel({
    required this.id,
    required this.title,
    required this.artist,
    required this.bpm,
    required this.genre,
    required this.duration,
    required this.isFavorite,
    required this.semanticLabel,
  });

  factory SongModel.fromMap(Map<String, dynamic> map) {
    return SongModel(
      id: map['id'] as String,
      title: map['title'] as String,
      artist: map['artist'] as String,
      bpm: map['bpm'] as int,
      genre: map['genre'] as String,
      duration: map['duration'] as String,
      isFavorite: map['isFavorite'] as bool,
      semanticLabel: map['semanticLabel'] as String,
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'artist': artist,
    'bpm': bpm,
    'genre': genre,
    'duration': duration,
    'isFavorite': isFavorite,
    'semanticLabel': semanticLabel,
  };

  SongModel copyWith({bool? isFavorite}) => SongModel(
    id: id,
    title: title,
    artist: artist,
    bpm: bpm,
    genre: genre,
    duration: duration,
    isFavorite: isFavorite ?? this.isFavorite,
    semanticLabel: semanticLabel,
  );
}

class SongsLibraryScreen extends StatefulWidget {
  const SongsLibraryScreen({super.key});

  /// Shared song library — mutated in place so all screens see the same list.
  static final List<SongModel> sharedSongs = [
    SongModel(
      id: 's1',
      title: 'Midnight Drive',
      artist: 'Lena Voss',
      bpm: 118,
      genre: 'Indie Rock',
      duration: '3:42',
      isFavorite: true,
      semanticLabel: 'Music note icon representing Midnight Drive song',
    ),
    SongModel(
      id: 's2',
      title: 'Golden Hour',
      artist: 'Marcus Webb',
      bpm: 94,
      genre: 'Folk',
      duration: '4:15',
      isFavorite: false,
      semanticLabel: 'Music note icon representing Golden Hour song',
    ),
    SongModel(
      id: 's3',
      title: 'Neon Pulse',
      artist: 'DJ Farrukh',
      bpm: 138,
      genre: 'Electronic',
      duration: '5:02',
      isFavorite: true,
      semanticLabel: 'Music note icon representing Neon Pulse song',
    ),
    SongModel(
      id: 's4',
      title: 'River Stone',
      artist: 'Amara Diallo',
      bpm: 72,
      genre: 'Soul',
      duration: '3:58',
      isFavorite: false,
      semanticLabel: 'Music note icon representing River Stone song',
    ),
    SongModel(
      id: 's5',
      title: 'Broken Signal',
      artist: 'The Northside',
      bpm: 126,
      genre: 'Post-Punk',
      duration: '3:21',
      isFavorite: false,
      semanticLabel: 'Music note icon representing Broken Signal song',
    ),
    SongModel(
      id: 's6',
      title: 'Velvet Underground',
      artist: 'Priya Mehta',
      bpm: 85,
      genre: 'Jazz-Funk',
      duration: '6:10',
      isFavorite: true,
      semanticLabel: 'Music note icon representing Velvet Underground song',
    ),
    SongModel(
      id: 's7',
      title: 'Last Train Home',
      artist: 'Callum Reid',
      bpm: 68,
      genre: 'Acoustic',
      duration: '4:33',
      isFavorite: false,
      semanticLabel: 'Music note icon representing Last Train Home song',
    ),
    SongModel(
      id: 's8',
      title: 'Static Sky',
      artist: 'Yuki Tanaka',
      bpm: 145,
      genre: 'Synth-Pop',
      duration: '3:55',
      isFavorite: false,
      semanticLabel: 'Music note icon representing Static Sky song',
    ),
    SongModel(
      id: 's9',
      title: 'Warm Front',
      artist: 'Lena Voss',
      bpm: 102,
      genre: 'Indie Pop',
      duration: '3:30',
      isFavorite: true,
      semanticLabel: 'Music note icon representing Warm Front song',
    ),
    SongModel(
      id: 's10',
      title: 'Deep Blue',
      artist: 'Amara Diallo',
      bpm: 78,
      genre: 'R&B',
      duration: '4:48',
      isFavorite: false,
      semanticLabel: 'Music note icon representing Deep Blue song',
    ),
  ];

  @override
  State<SongsLibraryScreen> createState() => _SongsLibraryScreenState();
}

class _SongsLibraryScreenState extends State<SongsLibraryScreen>
    with SingleTickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production
  String _searchQuery = '';
  final String _bpmFilter = 'All';
  late AnimationController _listAnimController;

  @override
  void initState() {
    super.initState();
    _listAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
  }

  @override
  void dispose() {
    _listAnimController.dispose();
    super.dispose();
  }

  List<SongModel> get _filteredSongs {
    return SongsLibraryScreen.sharedSongs.where((s) {
      final matchesSearch =
          s.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          s.artist.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesBpm =
          _bpmFilter == 'All' ||
          (_bpmFilter == 'Slow' && s.bpm <= 80) ||
          (_bpmFilter == 'Mid' && s.bpm > 80 && s.bpm <= 120) ||
          (_bpmFilter == 'Fast' && s.bpm > 120);
      return matchesSearch && matchesBpm;
    }).toList();
  }

  void _toggleFavorite(String id) {
    setState(() {
      final idx = SongsLibraryScreen.sharedSongs.indexWhere((s) => s.id == id);
      if (idx != -1) {
        SongsLibraryScreen.sharedSongs[idx] = SongsLibraryScreen
            .sharedSongs[idx]
            .copyWith(
              isFavorite: !SongsLibraryScreen.sharedSongs[idx].isFavorite,
            );
      }
    });
    AppStorage.saveSongs();
  }

  void _deleteSong(String id) {
    setState(
      () => SongsLibraryScreen.sharedSongs.removeWhere((s) => s.id == id),
    );
    AppStorage.saveSongs();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Song deleted'),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _editSong(SongModel song) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddSongSheetWidget(
        existingSong: song,
        onAdd: (updatedSong) {
          setState(() {
            final idx = SongsLibraryScreen.sharedSongs.indexWhere(
              (s) => s.id == song.id,
            );
            if (idx != -1) SongsLibraryScreen.sharedSongs[idx] = updatedSong;
          });
          AppStorage.saveSongs();
          Navigator.pop(context);
        },
      ),
    );
  }

  void _openAddSong() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddSongSheetWidget(
        onAdd: (song) {
          setState(() => SongsLibraryScreen.sharedSongs.add(song));
          AppStorage.saveSongs();
          Navigator.pop(context);
        },
      ),
    );
  }

  bool get _isTablet => MediaQuery.of(context).size.width >= 600;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final filtered = _filteredSongs;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),
            // Search bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SongsSearchBarWidget(
                onChanged: (q) => setState(() => _searchQuery = q),
              ),
            ),
            const SizedBox(height: 12),
            // BPM filter chips hidden
            const SizedBox(height: 8),
            // Song count
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Text(
                '${filtered.length} song${filtered.length != 1 ? 's' : ''}',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            // Song list
            Expanded(
              child: filtered.isEmpty
                  ? EmptyStateWidget(
                      icon: Icons.music_note_outlined,
                      title: 'No songs found',
                      subtitle:
                          'Try a different search or BPM filter, or add a new song to your library.',
                      actionLabel: 'Add Song',
                      onAction: _openAddSong,
                    )
                  : _isTablet
                  ? _buildTabletGrid(filtered, theme)
                  : _buildPhoneList(filtered),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddSong,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add Song'),
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildPhoneList(List<SongModel> songs) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
      itemCount: songs.length,
      itemBuilder: (context, index) {
        final delay = (index * 50).clamp(0, 400);
        return AnimatedBuilder(
          animation: _listAnimController,
          builder: (context, child) {
            final progress = Curves.easeOutCubic.transform(
              (((_listAnimController.value * 600) - delay) / 350).clamp(
                0.0,
                1.0,
              ),
            );
            return Opacity(
              opacity: progress,
              child: Transform.translate(
                offset: Offset(0, 20 * (1 - progress)),
                child: child,
              ),
            );
          },
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: SongListItemWidget(
              song: songs[index],
              onFavoriteToggle: () => _toggleFavorite(songs[index].id),
              onEdit: () => _editSong(songs[index]),
              onDelete: () => _deleteSong(songs[index].id),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTabletGrid(List<SongModel> songs, ThemeData theme) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 8,
        crossAxisSpacing: 12,
        childAspectRatio: 3.5,
      ),
      itemCount: songs.length,
      itemBuilder: (context, index) => SongListItemWidget(
        song: songs[index],
        onFavoriteToggle: () => _toggleFavorite(songs[index].id),
        onEdit: () => _editSong(songs[index]),
        onDelete: () => _deleteSong(songs[index].id),
      ),
    );
  }
}
