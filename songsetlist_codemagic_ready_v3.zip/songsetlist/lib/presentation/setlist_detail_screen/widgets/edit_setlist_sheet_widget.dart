import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../setlists_screen/setlists_screen.dart';
import '../../songs_library_screen/songs_library_screen.dart';

class EditSetlistSheetWidget extends StatefulWidget {
  final SetlistModel setlist;
  final List<SongModel> orderedSongs;
  final void Function(SetlistModel updated, List<SongModel> songs) onSave;

  const EditSetlistSheetWidget({
    required this.setlist,
    required this.orderedSongs,
    required this.onSave,
    super.key,
  });

  @override
  State<EditSetlistSheetWidget> createState() => _EditSetlistSheetWidgetState();
}

class _EditSetlistSheetWidgetState extends State<EditSetlistSheetWidget>
    with SingleTickerProviderStateMixin {
  late TextEditingController _nameController;
  late TextEditingController _venueController;
  late TextEditingController _dateController;
  late SetlistStatus _selectedStatus;
  late List<SongModel> _songs;
  late TabController _tabController;

  // Removed hardcoded _allSongs — now uses SongsLibraryScreen.sharedSongs

  String _songSearchQuery = '';
  final TextEditingController _songSearchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.setlist.name);
    _venueController = TextEditingController(text: widget.setlist.venue);
    _dateController = TextEditingController(text: widget.setlist.date);
    _selectedStatus = widget.setlist.status;
    _songs = List<SongModel>.from(widget.orderedSongs);
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _venueController.dispose();
    _dateController.dispose();
    _songSearchCtrl.dispose();
    _tabController.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameController.text.trim();
    final venue = _venueController.text.trim();
    final date = _dateController.text.trim();
    if (name.isEmpty) return;

    final updated = SetlistModel(
      id: widget.setlist.id,
      name: name,
      venue: venue.isEmpty ? widget.setlist.venue : venue,
      date: date.isEmpty ? widget.setlist.date : date,
      status: _selectedStatus,
      songCount: _songs.length,
      totalDuration: widget.setlist.totalDuration,
      isPinned: widget.setlist.isPinned,
      songIds: _songs.map((s) => s.id).toList(),
    );
    widget.onSave(updated, _songs);
    Navigator.of(context).pop();
  }

  Future<void> _pickDate() async {
    DateTime? initial;
    try {
      final parts = _dateController.text.split(' ');
      if (parts.length == 3) {
        final months = {
          'Jan': 1,
          'Feb': 2,
          'Mar': 3,
          'Apr': 4,
          'May': 5,
          'Jun': 6,
          'Jul': 7,
          'Aug': 8,
          'Sep': 9,
          'Oct': 10,
          'Nov': 11,
          'Dec': 12,
        };
        final month = months[parts[0]];
        final day = int.tryParse(parts[1].replaceAll(',', ''));
        final year = int.tryParse(parts[2]);
        if (month != null && day != null && year != null) {
          initial = DateTime(year, month, day);
        }
      }
    } catch (_) {}
    initial ??= DateTime.now();

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      const monthNames = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
      setState(() {
        _dateController.text =
            '${monthNames[picked.month - 1]} ${picked.day}, ${picked.year}';
      });
    }
  }

  void _addSong(SongModel song) {
    setState(() {
      _songs.add(song);
    });
  }

  void _removeSong(int index) {
    setState(() {
      _songs.removeAt(index);
    });
  }

  void _reorderSongs(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) newIndex--;
      final item = _songs.removeAt(oldIndex);
      _songs.insert(newIndex, item);
    });
  }

  List<SongModel> get _filteredLibrarySongs {
    final library = SongsLibraryScreen.sharedSongs;
    if (_songSearchQuery.isEmpty) return library;
    final q = _songSearchQuery.toLowerCase();
    return library
        .where(
          (s) =>
              s.title.toLowerCase().contains(q) ||
              s.artist.toLowerCase().contains(q) ||
              s.genre.toLowerCase().contains(q),
        )
        .toList();
  }

  Color _bpmColor(int bpm) {
    if (bpm <= 80) return const Color(0xFF2D7A4F);
    if (bpm <= 120) return const Color(0xFFB45309);
    return const Color(0xFF8B1A1A);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    final screenHeight = MediaQuery.of(context).size.height;

    return Container(
      height: screenHeight * 0.92,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          // Drag handle
          Center(
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: theme.colorScheme.outlineVariant,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Text(
                  'Edit Setlist',
                  style: GoogleFonts.dmSans(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text(
                    'Cancel',
                    style: GoogleFonts.dmSans(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                const SizedBox(width: 4),
                FilledButton(
                  onPressed: _save,
                  style: FilledButton.styleFrom(
                    backgroundColor: theme.colorScheme.primary,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text(
                    'Save',
                    style: GoogleFonts.dmSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          // Tabs
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(10),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: theme.colorScheme.primary,
                  borderRadius: BorderRadius.circular(8),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                labelColor: Colors.white,
                unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
                dividerColor: Colors.transparent,
                labelStyle: GoogleFonts.dmSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
                unselectedLabelStyle: GoogleFonts.dmSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
                tabs: const [
                  Tab(text: 'Songs'),
                  Tab(text: 'Details'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // ── Songs tab ──
                Column(
                  children: [
                    // Search box at the top
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: TextField(
                          controller: _songSearchCtrl,
                          onChanged: (v) =>
                              setState(() => _songSearchQuery = v),
                          style: GoogleFonts.dmSans(
                            fontSize: 13,
                            color: theme.colorScheme.onSurface,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Search songs…',
                            hintStyle: GoogleFonts.dmSans(
                              fontSize: 13,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            prefixIcon: Icon(
                              Icons.search_rounded,
                              size: 18,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            suffixIcon: _songSearchQuery.isNotEmpty
                                ? GestureDetector(
                                    onTap: () {
                                      _songSearchCtrl.clear();
                                      setState(() => _songSearchQuery = '');
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Icon(
                                        Icons.close_rounded,
                                        size: 26,
                                        color:
                                            theme.colorScheme.onSurfaceVariant,
                                      ),
                                    ),
                                  )
                                : null,
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 10,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Song library header
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          Text(
                            'Song Library',
                            style: GoogleFonts.dmSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: theme.colorScheme.onSurface,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            'Check to add',
                            style: GoogleFonts.dmSans(
                              fontSize: 11,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Library songs list
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                        itemCount: _filteredLibrarySongs.length,
                        itemBuilder: (context, index) {
                          final song = _filteredLibrarySongs[index];
                          final bc = _bpmColor(song.bpm);
                          return Container(
                            margin: const EdgeInsets.only(bottom: 6),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.surface,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: theme.colorScheme.outlineVariant,
                              ),
                            ),
                            child: Row(
                              children: [
                                const SizedBox(width: 12),
                                Container(
                                  width: 3,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    color: bc.withAlpha(128),
                                    borderRadius: BorderRadius.circular(2),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 10,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          song.title,
                                          style: GoogleFonts.dmSans(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                            color: theme.colorScheme.onSurface,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Text(
                                          '${song.artist} · ${song.genre}',
                                          style: GoogleFonts.dmSans(
                                            fontSize: 11,
                                            color: theme
                                                .colorScheme
                                                .onSurfaceVariant,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: bc.withAlpha(26),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    '${song.bpm}',
                                    style: GoogleFonts.dmSans(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: bc,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Checkbox(
                                  value: _songs.contains(song),
                                  onChanged: (checked) {
                                    if (checked ?? false) {
                                      _addSong(song);
                                    } else {
                                      _removeSong(_songs.indexOf(song));
                                    }
                                  },
                                ),
                                const SizedBox(width: 6),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),

                // ── Details tab ──
                SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(20, 8, 20, 20 + bottomInset),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _FieldLabel(label: 'Setlist Name', theme: theme),
                      const SizedBox(height: 6),
                      _StyledTextField(
                        controller: _nameController,
                        hint: 'e.g. Friday Night at The Anchor',
                        theme: theme,
                      ),
                      const SizedBox(height: 14),
                      _FieldLabel(label: 'Venue', theme: theme),
                      const SizedBox(height: 6),
                      _StyledTextField(
                        controller: _venueController,
                        hint: 'e.g. The Anchor Bar',
                        theme: theme,
                        prefixIcon: Icons.location_on_outlined,
                      ),
                      const SizedBox(height: 14),
                      _FieldLabel(label: 'Date', theme: theme),
                      const SizedBox(height: 6),
                      GestureDetector(
                        onTap: _pickDate,
                        child: AbsorbPointer(
                          child: _StyledTextField(
                            controller: _dateController,
                            hint: 'e.g. Aug 22, 2026',
                            theme: theme,
                            prefixIcon: Icons.calendar_today_outlined,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      _FieldLabel(label: 'Status', theme: theme),
                      const SizedBox(height: 8),
                      Row(
                        children: SetlistStatus.values.map((status) {
                          final isSelected = _selectedStatus == status;
                          final color = _statusColor(status, theme);
                          return Expanded(
                            child: GestureDetector(
                              onTap: () =>
                                  setState(() => _selectedStatus = status),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 180),
                                margin: const EdgeInsets.only(right: 8),
                                padding: const EdgeInsets.symmetric(
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? color.withAlpha(30)
                                      : theme
                                            .colorScheme
                                            .surfaceContainerHighest,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: isSelected
                                        ? color
                                        : Colors.transparent,
                                    width: 1.5,
                                  ),
                                ),
                                child: Center(
                                  child: Text(
                                    status.name[0].toUpperCase() +
                                        status.name.substring(1),
                                    style: GoogleFonts.dmSans(
                                      fontSize: 13,
                                      fontWeight: isSelected
                                          ? FontWeight.w700
                                          : FontWeight.w500,
                                      color: isSelected
                                          ? color
                                          : theme.colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _statusColor(SetlistStatus s, ThemeData theme) {
    switch (s) {
      case SetlistStatus.ready:
        return const Color(0xFF2D7A4F);
      case SetlistStatus.performed:
        return theme.colorScheme.primary;
      case SetlistStatus.draft:
        return theme.colorScheme.onSurfaceVariant;
    }
  }
}

class _FieldLabel extends StatelessWidget {
  final String label;
  final ThemeData theme;
  const _FieldLabel({required this.label, required this.theme});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: GoogleFonts.dmSans(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        letterSpacing: 0.5,
        color: theme.colorScheme.onSurfaceVariant,
      ),
    );
  }
}

class _StyledTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final ThemeData theme;
  final IconData? prefixIcon;

  const _StyledTextField({
    required this.controller,
    required this.hint,
    required this.theme,
    this.prefixIcon,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      style: GoogleFonts.dmSans(
        fontSize: 14,
        color: theme.colorScheme.onSurface,
      ),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: GoogleFonts.dmSans(
          fontSize: 14,
          color: theme.colorScheme.onSurfaceVariant.withAlpha(150),
        ),
        prefixIcon: prefixIcon != null
            ? Icon(
                prefixIcon,
                size: 16,
                color: theme.colorScheme.onSurfaceVariant,
              )
            : null,
        filled: true,
        fillColor: theme.colorScheme.surfaceContainerHighest,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: theme.colorScheme.primary, width: 1.5),
        ),
      ),
    );
  }
}
