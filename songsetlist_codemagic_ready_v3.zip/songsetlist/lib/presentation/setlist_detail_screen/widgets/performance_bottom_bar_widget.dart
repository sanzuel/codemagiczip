import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../setlists_screen/setlists_screen.dart';

class PerformanceBottomBarWidget extends StatelessWidget {
  final SetlistModel setlist;
  final bool isPerformanceMode;
  final int? currentSongIndex;
  final int totalSongs;
  final VoidCallback onStart;
  final VoidCallback onNext;
  final VoidCallback onEnd;

  const PerformanceBottomBarWidget({
    required this.setlist,
    required this.isPerformanceMode,
    required this.currentSongIndex,
    required this.totalSongs,
    required this.onStart,
    required this.onNext,
    required this.onEnd,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(color: theme.colorScheme.outlineVariant, width: 1),
        ),
      ),
      padding: EdgeInsets.fromLTRB(
        20,
        12,
        20,
        MediaQuery.of(context).padding.bottom + 12,
      ),
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        transitionBuilder: (child, animation) => FadeTransition(
          opacity: CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          ),
          child: child,
        ),
        child: isPerformanceMode
            ? _buildPerformanceBar(theme)
            : _buildStartBar(theme),
      ),
    );
  }

  Widget _buildStartBar(ThemeData theme) {
    return Row(
      key: const ValueKey('start'),
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$totalSongs songs · ${setlist.totalDuration}',
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              Text(
                setlist.venue,
                style: GoogleFonts.dmSans(
                  fontSize: 12,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 16),
        SizedBox(
          height: 48,
          child: FilledButton.icon(
            onPressed: onStart,
            icon: const Icon(Icons.play_arrow_rounded, size: 20),
            label: Text(
              'Start Performance',
              style: GoogleFonts.dmSans(
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            style: FilledButton.styleFrom(
              backgroundColor: theme.colorScheme.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 20),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPerformanceBar(ThemeData theme) {
    final current = (currentSongIndex ?? 0) + 1;
    final progress = totalSongs > 0 ? current / totalSongs : 0.0;

    return Column(
      key: const ValueKey('performance'),
      mainAxisSize: MainAxisSize.min,
      children: [
        // Progress bar
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: theme.colorScheme.outlineVariant,
            valueColor: AlwaysStoppedAnimation(theme.colorScheme.primary),
            minHeight: 4,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            // Song counter
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '$current / $totalSongs',
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.primary,
                  fontFeatures: [const FontFeature.tabularFigures()],
                ),
              ),
            ),
            const Spacer(),
            // End button
            TextButton(
              onPressed: onEnd,
              style: TextButton.styleFrom(
                foregroundColor: theme.colorScheme.onSurfaceVariant,
                padding: const EdgeInsets.symmetric(horizontal: 12),
              ),
              child: Text(
                'End',
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Next song button
            SizedBox(
              height: 44,
              child: FilledButton.icon(
                onPressed: current < totalSongs ? onNext : null,
                icon: const Icon(Icons.skip_next_rounded, size: 20),
                label: Text(
                  'Next Song',
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                style: FilledButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: theme.colorScheme.outlineVariant,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
