import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../setlists_screen/setlists_screen.dart';
import '../../../widgets/status_badge_widget.dart';

class SetlistHeaderWidget extends StatefulWidget {
  final SetlistModel setlist;
  final int avgBpm;
  final int songCount;
  final ValueChanged<String>? onNameChanged;

  const SetlistHeaderWidget({
    required this.setlist,
    required this.avgBpm,
    required this.songCount,
    this.onNameChanged,
    super.key,
  });

  @override
  State<SetlistHeaderWidget> createState() => _SetlistHeaderWidgetState();
}

class _SetlistHeaderWidgetState extends State<SetlistHeaderWidget> {
  bool _isEditing = false;
  late TextEditingController _nameController;
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.setlist.name);
    _focusNode = FocusNode();
    _focusNode.addListener(() {
      if (!_focusNode.hasFocus && _isEditing) {
        _commitEdit();
      }
    });
  }

  @override
  void didUpdateWidget(SetlistHeaderWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!_isEditing && oldWidget.setlist.name != widget.setlist.name) {
      _nameController.text = widget.setlist.name;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _startEditing() {
    setState(() {
      _isEditing = true;
      _nameController.text = widget.setlist.name;
      _nameController.selection = TextSelection(
        baseOffset: 0,
        extentOffset: _nameController.text.length,
      );
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  void _commitEdit() {
    final newName = _nameController.text.trim();
    setState(() => _isEditing = false);
    if (newName.isNotEmpty && newName != widget.setlist.name) {
      widget.onNameChanged?.call(newName);
    } else {
      _nameController.text = widget.setlist.name;
    }
  }

  Color _statusColor(SetlistStatus s, ThemeData theme) {
    switch (s) {
      case SetlistStatus.ready:
        return const Color(0xFF2D7A4F);
      case SetlistStatus.performed:
        return theme.colorScheme.primary;
      case SetlistStatus.draft:
        return theme.colorScheme.onSurfaceVariant;
    }
  }

  BadgeType _badgeType(SetlistStatus s) {
    switch (s) {
      case SetlistStatus.ready:
        return BadgeType.ready;
      case SetlistStatus.performed:
        return BadgeType.performed;
      case SetlistStatus.draft:
        return BadgeType.draft;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Setlist name — large title with double-tap to edit
          _isEditing
              ? TextField(
                  controller: _nameController,
                  focusNode: _focusNode,
                  style: GoogleFonts.dmSans(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                    height: 1.25,
                  ),
                  decoration: InputDecoration(
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 6,
                    ),
                    filled: true,
                    fillColor: theme.colorScheme.surfaceContainerHighest.withAlpha(128),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: theme.colorScheme.primary,
                        width: 1.5,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: theme.colorScheme.primary,
                        width: 1.5,
                      ),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        Icons.check_rounded,
                        color: theme.colorScheme.primary,
                        size: 20,
                      ),
                      onPressed: _commitEdit,
                      tooltip: 'Save name',
                    ),
                  ),
                  onSubmitted: (_) => _commitEdit(),
                  textInputAction: TextInputAction.done,
                )
              : GestureDetector(
                  onDoubleTap: _startEditing,
                  child: Text(
                    widget.setlist.name,
                    style: GoogleFonts.dmSans(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                      height: 1.25,
                    ),
                  ),
                ),
          const SizedBox(height: 8),
          // Venue + date
          Row(
            children: [
              Icon(
                Icons.location_on_outlined,
                size: 14,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  widget.setlist.venue,
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                Icons.calendar_today_outlined,
                size: 14,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 4),
              Text(
                widget.setlist.date,
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Stats row hidden
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color color;

  const _StatItem({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(height: 4),
        Text(
          value,
          style: GoogleFonts.dmSans(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: color,
            fontFeatures: [const FontFeature.tabularFigures()],
          ),
        ),
        Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 11,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _VerticalDivider extends StatelessWidget {
  final Color color;
  const _VerticalDivider({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 40, color: color);
  }
}
