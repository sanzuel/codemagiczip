import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../songs_library_screen/songs_library_screen.dart';

class SetlistSongRowWidget extends StatefulWidget {
  final SongModel song;
  final int orderNumber;
  final bool isCurrentSong;
  final bool isPerformanceMode;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final int? reorderIndex;

  const SetlistSongRowWidget({
    required this.song,
    required this.orderNumber,
    required this.isCurrentSong,
    required this.isPerformanceMode,
    this.onTap,
    this.onDelete,
    this.reorderIndex,
    super.key,
  });

  @override
  State<SetlistSongRowWidget> createState() => _SetlistSongRowWidgetState();
}

class _SetlistSongRowWidgetState extends State<SetlistSongRowWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _slideAnim;

  static const double _deleteRevealWidth = 80.0;
  bool _isRevealed = false;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _slideAnim = Tween<double>(begin: 0, end: -_deleteRevealWidth).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void _reveal() {
    setState(() => _isRevealed = true);
    _animController.forward();
  }

  void _hide() {
    _animController.reverse().then((_) {
      if (mounted) setState(() => _isRevealed = false);
    });
  }

  void _onHorizontalDragUpdate(DragUpdateDetails details) {
    if (details.delta.dx < -4 && !_isRevealed) {
      _reveal();
    } else if (details.delta.dx > 4 && _isRevealed) {
      _hide();
    }
  }

  Color _bpmColor(int bpm) {
    if (bpm <= 80) return const Color(0xFF2D7A4F);
    if (bpm <= 120) return const Color(0xFF3EB489);
    return const Color(0xFF3EB489);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bc = _bpmColor(widget.song.bpm);

    return GestureDetector(
      onHorizontalDragUpdate: _onHorizontalDragUpdate,
      onTap: _isRevealed ? _hide : null,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            // Delete button background (revealed on swipe left)
            Positioned.fill(
              child: Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: _deleteRevealWidth,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.error,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      _hide();
                      widget.onDelete?.call();
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.delete_outline_rounded,
                          size: 22,
                          color: theme.colorScheme.onError,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Delete',
                          style: GoogleFonts.dmSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: theme.colorScheme.onError,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Foreground song row — slides left to reveal delete
            AnimatedBuilder(
              animation: _slideAnim,
              builder: (context, child) => Transform.translate(
                offset: Offset(_slideAnim.value, 0),
                child: child,
              ),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: widget.isCurrentSong
                      ? theme.colorScheme.primaryContainer
                      : theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: widget.isCurrentSong
                        ? theme.colorScheme.primary.withAlpha(102)
                        : theme.colorScheme.outlineVariant,
                    width: widget.isCurrentSong ? 1.5 : 1,
                  ),
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: _isRevealed ? _hide : widget.onTap,
                    borderRadius: BorderRadius.circular(16),
                    splashColor: theme.colorScheme.primary.withAlpha(15),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                      child: Row(
                        children: [
                          // BPM tempo indicator bar
                          Container(
                            width: 3,
                            height: 36,
                            decoration: BoxDecoration(
                              color: bc.withOpacity(
                                widget.isCurrentSong ? 1.0 : 0.5,
                              ),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Title + artist
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.song.title,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: theme.colorScheme.onSurface,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '${widget.song.artist} · ${widget.song.genre}',
                                  style: GoogleFonts.dmSans(
                                    fontSize: 12,
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          // BPM badge
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 7,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: bc.withAlpha(26),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Text(
                              '${widget.song.bpm}',
                              style: GoogleFonts.dmSans(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: bc,
                                fontFeatures: [
                                  const FontFeature.tabularFigures(),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Reorder handle — visible only on songs inside a setlist.
                          // The instruction banner is intentionally omitted; users can
                          // long-press the song or this handle to reorder.
                          if (widget.reorderIndex != null)
                            ReorderableDragStartListener(
                              index: widget.reorderIndex!,
                              child: Icon(
                                Icons.drag_handle_rounded,
                                size: 22,
                                color: theme.colorScheme.outline,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
