import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_storage.dart';

import '../setlists_screen/setlists_screen.dart';
import '../songs_library_screen/songs_library_screen.dart';
import './widgets/setlist_header_widget.dart';
import './widgets/setlist_song_row_widget.dart';
import './widgets/edit_setlist_sheet_widget.dart';
import '../../widgets/empty_state_widget.dart';

// TODO: Replace with Riverpod/Bloc for production

class SetlistDetailScreen extends StatefulWidget {
  final String setlistId;
  final SetlistModel? setlistModel;
  const SetlistDetailScreen({
    required this.setlistId,
    this.setlistModel,
    super.key,
  });

  @override
  State<SetlistDetailScreen> createState() => _SetlistDetailScreenState();
}

class _SetlistDetailScreenState extends State<SetlistDetailScreen> {
  // TODO: Replace with Riverpod/Bloc for production
  late SetlistModel _setlist;
  late List<SongModel> _orderedSongs;
  int? _currentSongIndex;
  bool _isPerformanceMode = false;

  Map<String, SongModel> get _songLibrary {
    final map = <String, SongModel>{};
    for (final song in SongsLibraryScreen.sharedSongs) {
      map[song.id] = song;
    }
    // Also include built-in songs not in sharedSongs
    const builtIn = <String, Map<String, dynamic>>{
      's1': {
        'id': 's1',
        'title': 'Midnight Drive',
        'artist': 'Lena Voss',
        'bpm': 118,
        'genre': 'Indie Rock',
        'duration': '3:42',
        'isFavorite': true,
        'semanticLabel': 'Music note icon for Midnight Drive',
      },
      's2': {
        'id': 's2',
        'title': 'Golden Hour',
        'artist': 'Marcus Webb',
        'bpm': 94,
        'genre': 'Folk',
        'duration': '4:15',
        'isFavorite': false,
        'semanticLabel': 'Music note icon for Golden Hour',
      },
      's3': {
        'id': 's3',
        'title': 'Neon Pulse',
        'artist': 'DJ Farrukh',
        'bpm': 138,
        'genre': 'Electronic',
        'duration': '5:02',
        'isFavorite': true,
        'semanticLabel': 'Music note icon for Neon Pulse',
      },
      's4': {
        'id': 's4',
        'title': 'River Stone',
        'artist': 'Amara Diallo',
        'bpm': 72,
        'genre': 'Soul',
        'duration': '3:58',
        'isFavorite': false,
        'semanticLabel': 'Music note icon for River Stone',
      },
      's5': {
        'id': 's5',
        'title': 'Broken Signal',
        'artist': 'The Northside',
        'bpm': 126,
        'genre': 'Post-Punk',
        'duration': '3:21',
        'isFavorite': false,
        'semanticLabel': 'Music note icon for Broken Signal',
      },
      's6': {
        'id': 's6',
        'title': 'Velvet Underground',
        'artist': 'Priya Mehta',
        'bpm': 85,
        'genre': 'Jazz-Funk',
        'duration': '6:10',
        'isFavorite': true,
        'semanticLabel': 'Music note icon for Velvet Underground',
      },
      's7': {
        'id': 's7',
        'title': 'Last Train Home',
        'artist': 'Callum Reid',
        'bpm': 68,
        'genre': 'Acoustic',
        'duration': '4:33',
        'isFavorite': false,
        'semanticLabel': 'Music note icon for Last Train Home',
      },
      's8': {
        'id': 's8',
        'title': 'Static Sky',
        'artist': 'Yuki Tanaka',
        'bpm': 145,
        'genre': 'Synth-Pop',
        'duration': '3:55',
        'isFavorite': false,
        'semanticLabel': 'Music note icon for Static Sky',
      },
      's9': {
        'id': 's9',
        'title': 'Warm Front',
        'artist': 'Lena Voss',
        'bpm': 102,
        'genre': 'Indie Pop',
        'duration': '3:30',
        'isFavorite': true,
        'semanticLabel': 'Music note icon for Warm Front',
      },
      's10': {
        'id': 's10',
        'title': 'Deep Blue',
        'artist': 'Amara Diallo',
        'bpm': 78,
        'genre': 'R&B',
        'duration': '4:48',
        'isFavorite': false,
        'semanticLabel': 'Music note icon for Deep Blue',
      },
    };
    for (final entry in builtIn.entries) {
      if (!map.containsKey(entry.key)) {
        map[entry.key] = SongModel.fromMap(entry.value);
      }
    }
    return map;
  }

  @override
  void initState() {
    super.initState();
    _loadSetlist();
  }

  void _loadSetlist() {
    // Look up from shared store first
    final sharedIdx = SetlistsScreen.sharedSetlists.indexWhere(
      (s) => s.id == widget.setlistId,
    );
    if (sharedIdx != -1) {
      _setlist = SetlistsScreen.sharedSetlists[sharedIdx];
    } else if (widget.setlistModel != null) {
      _setlist = widget.setlistModel!;
    } else {
      // Fallback: use passed model or first in shared store
      _setlist = SetlistsScreen.sharedSetlists.isNotEmpty
          ? SetlistsScreen.sharedSetlists.first
          : widget.setlistModel ??
                SetlistModel.fromMap({
                  'id': widget.setlistId,
                  'name': 'Setlist',
                  'venue': 'TBD',
                  'date': 'TBD',
                  'status': 'draft',
                  'songCount': 0,
                  'totalDuration': '0:00',
                  'isPinned': false,
                  'songIds': <String>[],
                });
    }
    final lib = _songLibrary;
    _orderedSongs = _setlist.songIds
        .map((id) => lib[id])
        .where((s) => s != null)
        .cast<SongModel>()
        .toList();
  }

  int get _avgBpm {
    if (_orderedSongs.isEmpty) return 0;
    return (_orderedSongs.fold(0, (sum, s) => sum + s.bpm) /
            _orderedSongs.length)
        .round();
  }

  void _reorder(int oldIndex, int newIndex) {
    // TODO: Replace with Riverpod/Bloc for production
    setState(() {
      if (newIndex > oldIndex) newIndex--;
      final item = _orderedSongs.removeAt(oldIndex);
      _orderedSongs.insert(newIndex, item);
      _persistSongsToSharedStore();
    });
  }

  void _deleteSong(int index) {
    setState(() {
      _orderedSongs.removeAt(index);
      if (_currentSongIndex != null) {
        if (_currentSongIndex == index) {
          _currentSongIndex = null;
        } else if (_currentSongIndex! > index) {
          _currentSongIndex = _currentSongIndex! - 1;
        }
      }
      _persistSongsToSharedStore();
    });
  }

  /// Writes the current song list back to the shared setlist store.
  void _persistSongsToSharedStore() {
    final idx = SetlistsScreen.sharedSetlists.indexWhere(
      (s) => s.id == _setlist.id,
    );
    if (idx != -1) {
      final s = SetlistsScreen.sharedSetlists[idx];
      SetlistsScreen.sharedSetlists[idx] = SetlistModel(
        id: s.id,
        name: s.name,
        venue: s.venue,
        date: s.date,
        status: s.status,
        songCount: _orderedSongs.length,
        totalDuration: s.totalDuration,
        isPinned: s.isPinned,
        songIds: _orderedSongs.map((song) => song.id).toList(),
      );
      _setlist = SetlistsScreen.sharedSetlists[idx];
      AppStorage.saveSetlists();
    }
  }

  void _markCurrentSong(int index) {
    // TODO: Replace with Riverpod/Bloc for production
    setState(() {
      _currentSongIndex = index;
    });
  }

  void _renameSetlist(String newName) {
    final idx = SetlistsScreen.sharedSetlists.indexWhere(
      (s) => s.id == _setlist.id,
    );
    setState(() {
      if (idx != -1) {
        final s = SetlistsScreen.sharedSetlists[idx];
        SetlistsScreen.sharedSetlists[idx] = SetlistModel(
          id: s.id,
          name: newName,
          venue: s.venue,
          date: s.date,
          status: s.status,
          songCount: s.songCount,
          totalDuration: s.totalDuration,
          isPinned: s.isPinned,
          songIds: s.songIds,
        );
        _setlist = SetlistsScreen.sharedSetlists[idx];
      } else {
        _setlist = SetlistModel(
          id: _setlist.id,
          name: newName,
          venue: _setlist.venue,
          date: _setlist.date,
          status: _setlist.status,
          songCount: _setlist.songCount,
          totalDuration: _setlist.totalDuration,
          isPinned: _setlist.isPinned,
          songIds: _setlist.songIds,
        );
      }
    });
    AppStorage.saveSetlists();
  }

  void _startPerformance() {
    // TODO: Replace with Riverpod/Bloc for production
    setState(() {
      _isPerformanceMode = true;
      _currentSongIndex = 0;
    });
  }

  void _openEditSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => EditSetlistSheetWidget(
        setlist: _setlist,
        orderedSongs: _orderedSongs,
        onSave: (updated, songs) {
          setState(() {
            _setlist = updated;
            _orderedSongs = songs;
          });
          // Persist updated setlist (name, venue, date, status, songs) to shared store
          final idx = SetlistsScreen.sharedSetlists.indexWhere(
            (s) => s.id == updated.id,
          );
          if (idx != -1) {
            SetlistsScreen.sharedSetlists[idx] = updated;
          } else {
            SetlistsScreen.sharedSetlists.add(updated);
          }
          AppStorage.saveSetlists();
        },
      ),
    );
  }

  bool get _isTablet => MediaQuery.of(context).size.width >= 600;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: _isTablet ? _buildTablet(theme) : _buildPhone(theme),
      ),
    );
  }

  Widget _buildPhone(ThemeData theme) {
    return Column(
      children: [
        // Floating pill AppBar — detail style from reference image
        _buildDetailAppBar(theme),
        Expanded(
          child: _orderedSongs.isEmpty
              ? _buildEmptyState(theme)
              : ReorderableListView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                  header: Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: SetlistHeaderWidget(
                      setlist: _setlist,
                      avgBpm: _avgBpm,
                      songCount: _orderedSongs.length,
                      onNameChanged: _renameSetlist,
                    ),
                  ),
                  itemCount: _orderedSongs.length,
                  onReorder: _reorder,
                  proxyDecorator: (child, index, animation) => Material(
                    elevation: 4,
                    borderRadius: BorderRadius.circular(16),
                    child: child,
                  ),
                  itemBuilder: (context, index) {
                    final song = _orderedSongs[index];
                    return Padding(
                      key: ValueKey('${song.id}_$index'),
                      padding: const EdgeInsets.only(bottom: 8),
                      child: SetlistSongRowWidget(
                        song: song,
                        orderNumber: index + 1,
                        isCurrentSong: _currentSongIndex == index,
                        isPerformanceMode: _isPerformanceMode,
                        onTap: _isPerformanceMode
                            ? () => _markCurrentSong(index)
                            : null,
                        onDelete: () => _deleteSong(index),
                        reorderIndex: index,
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildTablet(ThemeData theme) {
    return Row(
      children: [
        // Left: header panel
        SizedBox(
          width: 320,
          child: Column(
            children: [
              _buildDetailAppBar(theme),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                  child: SetlistHeaderWidget(
                    setlist: _setlist,
                    avgBpm: _avgBpm,
                    songCount: _orderedSongs.length,
                    onNameChanged: _renameSetlist,
                  ),
                ),
              ),
            ],
          ),
        ),
        VerticalDivider(width: 1, color: theme.colorScheme.outlineVariant),
        // Right: song list
        Expanded(
          child: _orderedSongs.isEmpty
              ? _buildEmptyState(theme)
              : ReorderableListView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
                  itemCount: _orderedSongs.length,
                  onReorder: _reorder,
                  proxyDecorator: (child, index, animation) => Material(
                    elevation: 4,
                    borderRadius: BorderRadius.circular(16),
                    child: child,
                  ),
                  itemBuilder: (context, index) {
                    final song = _orderedSongs[index];
                    return Padding(
                      key: ValueKey('${song.id}_$index'),
                      padding: const EdgeInsets.only(bottom: 8),
                      child: SetlistSongRowWidget(
                        song: song,
                        orderNumber: index + 1,
                        isCurrentSong: _currentSongIndex == index,
                        isPerformanceMode: _isPerformanceMode,
                        onTap: _isPerformanceMode
                            ? () => _markCurrentSong(index)
                            : null,
                        onDelete: () => _deleteSong(index),
                        reorderIndex: index,
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
          child: SetlistHeaderWidget(
            setlist: _setlist,
            avgBpm: 0,
            songCount: 0,
            onNameChanged: _renameSetlist,
          ),
        ),
        Expanded(
          child: EmptyStateWidget(
            icon: Icons.queue_music_rounded,
            title: 'No songs yet',
            subtitle: 'Tap the edit button to add songs to this setlist.',
          ),
        ),
      ],
    );
  }

  Widget _buildDetailAppBar(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Row(
        children: [
          // Back label — article detail style from reference
          GestureDetector(
            onTap: () => context.pop(),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.arrow_back_rounded,
                  size: 18,
                  color: theme.colorScheme.onSurface,
                ),
                const SizedBox(width: 4),
                Text(
                  'SETLISTS',
                  style: GoogleFonts.dmSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.5,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          // Share icon
          GestureDetector(
            onTap: () {},
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.share_outlined,
                size: 18,
                color: theme.colorScheme.onSurface,
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Edit icon
          GestureDetector(
            onTap: _openEditSheet,
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.edit_outlined,
                size: 18,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
