import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import './app_navigation.dart';

class AppScaffold extends StatelessWidget {
  final StatefulNavigationShell navigationShell;
  const AppScaffold({required this.navigationShell, super.key});

  void _onTabTap(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          AppNavigation(navigationShell: navigationShell),
          Expanded(
            child: GestureDetector(
              onHorizontalDragEnd: (details) {
                final velocity = details.primaryVelocity ?? 0;
                final currentIndex = navigationShell.currentIndex;
                // Swipe left (negative velocity) → go to next tab (Setlist)
                if (velocity < -300 && currentIndex == 0) {
                  _onTabTap(1);
                }
                // Swipe right (positive velocity) → go to previous tab (Songs)
                else if (velocity > 300 && currentIndex == 1) {
                  _onTabTap(0);
                }
              },
              child: navigationShell,
            ),
          ),
        ],
      ),
    );
  }
}
