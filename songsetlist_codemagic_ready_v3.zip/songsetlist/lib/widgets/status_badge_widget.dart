import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

enum BadgeType { draft, ready, performed, bpm, key, genre }

class StatusBadgeWidget extends StatelessWidget {
  final String label;
  final BadgeType type;
  final double? fontSize;

  const StatusBadgeWidget({
    required this.label,
    required this.type,
    this.fontSize,
    super.key,
  });

  Color _bgColor(ThemeData theme) {
    switch (type) {
      case BadgeType.draft:
        return theme.colorScheme.surfaceContainerHighest;
      case BadgeType.ready:
        return const Color(0xFFE8F5EE);
      case BadgeType.performed:
        return theme.colorScheme.primaryContainer;
      case BadgeType.bpm:
        return theme.colorScheme.primaryContainer;
      case BadgeType.key:
        return theme.colorScheme.secondaryContainer;
      case BadgeType.genre:
        return theme.colorScheme.surfaceContainerHighest;
    }
  }

  Color _textColor(ThemeData theme) {
    switch (type) {
      case BadgeType.draft:
        return theme.colorScheme.onSurfaceVariant;
      case BadgeType.ready:
        return const Color(0xFF2D7A4F);
      case BadgeType.performed:
        return theme.colorScheme.primary;
      case BadgeType.bpm:
        return theme.colorScheme.primary;
      case BadgeType.key:
        return theme.colorScheme.secondary;
      case BadgeType.genre:
        return theme.colorScheme.onSurfaceVariant;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: _bgColor(theme),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: GoogleFonts.dmSans(
          fontSize: fontSize ?? 11,
          fontWeight: FontWeight.w600,
          color: _textColor(theme),
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}
