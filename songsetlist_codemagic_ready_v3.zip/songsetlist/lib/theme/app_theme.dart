// THEME LOCK: dark — source: user override (black bg, mint green accent)
// Scaffold.backgroundColor = AppTheme.background — ALL screens

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Primary palette — mint green accent
  static const Color primary = Color(0xFF3EB489);
  static const Color primaryContainer = Color(0xFF1A3D30);
  static const Color secondary = Color(0xFF2DD4A0);
  static const Color secondaryContainer = Color(0xFF0F2E22);

  // Semantic colors
  static const Color success = Color(0xFF3EB489);
  static const Color warning = Color(0xFFB45309);
  static const Color error = Color(0xFFB91C1C);

  // Light surfaces (kept for compatibility)
  static const Color surfaceLight = Color(0xFFFAFAF7);
  static const Color surfaceVariantLight = Color(0xFFF2EFE8);
  static const Color backgroundLight = Color(0xFFF5F2EB);
  static const Color outlineLight = Color(0xFFD4CFC4);
  static const Color outlineVariantLight = Color(0xFFEBE8E0);

  // Dark surfaces — black theme
  static const Color surfaceDark = Color(0xFF111111);
  static const Color surfaceVariantDark = Color(0xFF1C1C1C);
  static const Color backgroundDark = Color(0xFF000000);

  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.dark(
      primary: primary,
      onPrimary: Colors.black,
      primaryContainer: primaryContainer,
      onPrimaryContainer: Color(0xFFB2F5DC),
      secondary: secondary,
      onSecondary: Colors.black,
      secondaryContainer: secondaryContainer,
      onSecondaryContainer: Color(0xFF9FFADC),
      surface: surfaceDark,
      onSurface: Color(0xFFEAEAEA),
      surfaceContainerHighest: surfaceVariantDark,
      onSurfaceVariant: Color(0xFFAAAAAA),
      error: error,
      onError: Colors.white,
      outline: Color(0xFF2A2A2A),
      outlineVariant: Color(0xFF1E1E1E),
    ),
    scaffoldBackgroundColor: backgroundDark,
    textTheme: GoogleFonts.dmSansTextTheme(
      TextTheme(
        displayLarge: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.5,
          color: Color(0xFFEAEAEA),
        ),
        displayMedium: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.5,
          color: Color(0xFFEAEAEA),
        ),
        headlineLarge: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w700,
          color: Color(0xFFEAEAEA),
        ),
        headlineMedium: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: Color(0xFFEAEAEA),
        ),
        headlineSmall: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: Color(0xFFEAEAEA),
        ),
        titleLarge: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: Color(0xFFEAEAEA),
        ),
        titleMedium: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: Color(0xFFEAEAEA),
        ),
        titleSmall: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: Color(0xFFEAEAEA),
        ),
        bodyLarge: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w400,
          color: Color(0xFFEAEAEA),
        ),
        bodyMedium: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w400,
          color: Color(0xFFCCCCCC),
        ),
        bodySmall: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w400,
          color: Color(0xFFAAAAAA),
        ),
        labelLarge: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.2,
          color: Color(0xFFEAEAEA),
        ),
        labelMedium: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          letterSpacing: 0.2,
          color: Color(0xFFCCCCCC),
        ),
        labelSmall: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w400,
          letterSpacing: 0.3,
          color: Color(0xFFAAAAAA),
        ),
      ),
    ),
    appBarTheme: AppBarThemeData(
      backgroundColor: backgroundDark,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      iconTheme: IconThemeData(color: Color(0xFFEAEAEA)),
      titleTextStyle: GoogleFonts.dmSans(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: Color(0xFFEAEAEA),
        letterSpacing: 0.5,
      ),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: surfaceDark,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Color(0xFF2A2A2A), width: 1),
      ),
    ),
    inputDecorationTheme: InputDecorationThemeData(
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Color(0xFF2A2A2A)),
      ),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Color(0xFF2A2A2A)),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: primary, width: 2),
      ),
      filled: false,
      contentPadding: EdgeInsets.symmetric(vertical: 12),
      labelStyle: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: Color(0xFFAAAAAA),
      ),
      hintStyle: TextStyle(fontSize: 14, color: Color(0xFF666666)),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: surfaceVariantDark,
      selectedColor: primary,
      labelStyle: GoogleFonts.dmSans(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: Color(0xFFEAEAEA),
      ),
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      shape: StadiumBorder(),
      side: BorderSide(color: Color(0xFF2A2A2A)),
    ),
    dividerTheme: DividerThemeData(
      color: Color(0xFF1E1E1E),
      thickness: 1,
      space: 0,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: primary,
      foregroundColor: Colors.black,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
  );

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.dark(
      primary: primary,
      onPrimary: Colors.black,
      primaryContainer: primaryContainer,
      onPrimaryContainer: Color(0xFFB2F5DC),
      secondary: secondary,
      onSecondary: Colors.black,
      surface: surfaceDark,
      onSurface: Color(0xFFEAEAEA),
      surfaceContainerHighest: surfaceVariantDark,
      onSurfaceVariant: Color(0xFFAAAAAA),
      error: Color(0xFFCF6679),
      onError: Colors.white,
      outline: Color(0xFF2A2A2A),
      outlineVariant: Color(0xFF1E1E1E),
    ),
    scaffoldBackgroundColor: backgroundDark,
    textTheme: GoogleFonts.dmSansTextTheme(
      TextTheme(
        displayLarge: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.w700,
          color: Color(0xFFEAEAEA),
        ),
        titleLarge: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: Color(0xFFEAEAEA),
        ),
        bodyMedium: TextStyle(fontSize: 13, color: Color(0xFFCCCCCC)),
        labelSmall: TextStyle(fontSize: 11, color: Color(0xFFAAAAAA)),
      ),
    ),
  );
}
