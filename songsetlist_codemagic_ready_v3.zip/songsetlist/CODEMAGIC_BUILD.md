# Build SongSetlist APK with Codemagic

1. Create/sign in to a Codemagic account.
2. Put this project in a GitHub repository (or upload/connect the repository through Codemagic).
3. Select the `android-apk` workflow from `codemagic.yaml`.
4. Start the build.
5. Download `app-release.apk` from the build Artifacts section.
6. Install that APK on the Android device.

This workflow builds a release APK using the project's current Android signing configuration. The project currently uses the Android debug signing configuration for release builds, so this APK is suitable for testing/direct installation. For Google Play Store publishing, configure a proper Play signing key/keystore in Codemagic and switch the Android release build to that signing configuration.

The app's local persistence fix is included. Songs and setlists are stored with SharedPreferences and loaded before the first screen is displayed.
